package com.spring.TuningSmile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TuningSmileApplicationTests {

	@Test
	void contextLoads() {
	}

}
